// script.js

// Подключение к серверу
const ws = new WebSocket("ws://localhost:8000/ws");

// Элементы интерфейса
const multiplierEl = document.getElementById('multiplier');
const logEl = document.getElementById('log');
const betBtn = document.getElementById('betBtn');
const cashoutBtn = document.getElementById('cashoutBtn');
const amountEl = document.getElementById('amount');
const autoEl = document.getElementById('auto');

// Генерация временного ID игрока
const user_id = Math.floor(Math.random() * 10000);

// === WebSocket события ===
ws.onopen = () => addLog("✅ Соединение установлено");

ws.onmessage = (event) => {
    try {
        const msg = JSON.parse(event.data);

        switch (msg.type) {
            case 'tick':
                multiplierEl.textContent = `x${msg.multiplier.toFixed(2)}`;
                multiplierEl.style.color = '#fbbf24'; // жёлтый при росте
                break;

            case 'crash':
                multiplierEl.style.color = '#ef4444'; // красный при краше
                addLog(`💥 Игра остановилась на x${msg.multiplier.toFixed(2)}`);
                break;

            case 'start':
                multiplierEl.style.color = '#22c55e'; // зелёный при старте
                addLog("🚀 Новый раунд");
                break;

            case 'cashout':
                addLog(`💰 Игрок ${msg.user_id} вывел на x${msg.multiplier}`);
                break;

            default:
                console.warn("Неизвестный тип сообщения:", msg);
        }

    } catch (e) {
        console.error("Ошибка парсинга данных", e);
    }
};

// === Кнопка «Ставка» ===
betBtn.onclick = () => {
    ws.send(JSON.stringify({
        action: "place_bet",
        user_id: user_id,
        amount: parseFloat(amountEl.value),
        auto: parseFloat(autoEl.value)
    }));
    addLog(`🎲 Ставка ${amountEl.value} при авто x${autoEl.value}`);
};

// === Кнопка «Кэшаут» ===
cashoutBtn.onclick = () => {
    ws.send(JSON.stringify({
        action: "cashout",
        user_id: user_id
    }));
    addLog("📤 Запрос кэшаута");
};

// === Логирование ===
function addLog(text) {
    logEl.innerHTML += text + "<br>";
    logEl.scrollTop = logEl.scrollHeight;
}
