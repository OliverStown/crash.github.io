from sqlalchemy import create_engine, Column, Integer, Float, String, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime

# Строка подключения к PostgreSQL через psycopg2
DATABASE_URL = "postgresql+psycopg2://postgres:0000@localhost:5432/crash_database"

# Инициализация SQLAlchemy
engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

# Модель ставки
class Bet(Base):
    __tablename__ = "bets"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, nullable=False)
    amount = Column(Float, nullable=False)
    auto_cashout = Column(Float, nullable=True)
    round_id = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    cashed_out_at = Column(Float, nullable=True)  # коэффициент кэшаута

# Сохранение ставки
def save_bet(user_id, amount, auto_cashout=None):
    session = SessionLocal()
    try:
        # Здесь можно получить текущий раунд из другой таблицы, пока заглушка:
        round_id = get_current_round_id()
        bet = Bet(
            user_id=user_id,
            amount=amount,
            auto_cashout=auto_cashout,
            round_id=round_id
        )
        session.add(bet)
        session.commit()
    finally:
        session.close()

# Получение текущего ID раунда (заглушка)
def get_current_round_id():
    return 42  # В реальности можно получить из таблицы rounds

# Завершение раунда — можно обновить ставки, которые не были кэшированы
def settle_round(round_id, crash_coeff):
    session = SessionLocal()
    try:
        # Обновим все ставки, которые не были кэшированы
        session.query(Bet).filter(
            Bet.round_id == round_id,
            Bet.cashed_out_at == None
        ).update({Bet.cashed_out_at: crash_coeff})
        session.commit()
        print(f"✅ Round {round_id} settled at coeff {crash_coeff}")
    finally:
        session.close()
