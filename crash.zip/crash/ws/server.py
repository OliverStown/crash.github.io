import asyncio
import json
import random
from aiohttp import web
from db import save_bet, get_current_round_id, settle_round

clients = set()
current_multiplier = 1.0
current_round_id = None
is_in_flight = False

# Хранилище ставок для текущего раунда
active_bets = {}

async def crash_loop():
    global current_multiplier, current_round_id, is_in_flight, active_bets
    while True:
        await asyncio.sleep(3)  # ожидание перед стартом
        current_multiplier = 1.0
        is_in_flight = True
        current_round_id = get_current_round_id()
        active_bets = {}  # очистка ставок
        await broadcast({"type": "start", "round_id": current_round_id})

        for _ in range(1000):
            await asyncio.sleep(0.1)
            current_multiplier += 0.05 + current_multiplier * 0.01
            await broadcast({"type": "tick", "coeff": round(current_multiplier, 2)})

            # авто-кэшаут
            to_cashout = []
            for user_id, bet in active_bets.items():
                if bet.get("auto_cashout") and current_multiplier >= bet["auto_cashout"]:
                    await process_cashout(user_id)
                    to_cashout.append(user_id)
            for uid in to_cashout:
                active_bets.pop(uid, None)

            if random.random() < 0.01:  # случайный краш
                await broadcast({"type": "crash", "coeff": round(current_multiplier, 2)})
                await settle_round(current_round_id, current_multiplier)
                is_in_flight = False
                break

async def process_cashout(user_id):
    # Здесь можно добавить логику выплаты
    await broadcast({"type": "cashout", "user_id": user_id, "coeff": round(current_multiplier, 2)})

async def broadcast(message):
    for ws in clients:
        try:
            await ws.send_str(json.dumps(message))
        except Exception:
            pass  # можно добавить логирование

async def websocket_handler(request):
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    clients.add(ws)

    try:
        async for msg in ws:
            if msg.type == web.WSMsgType.TEXT:
                data = json.loads(msg.data)
                if data.get("action") == "place_bet" and is_in_flight:
                    user_id = data.get("user_id", 1)
                    amount = data.get("amount")
                    auto_cashout = data.get("auto")
                    await save_bet(user_id=user_id, amount=amount, auto_cashout=auto_cashout)
                    active_bets[user_id] = {
                        "amount": amount,
                        "auto_cashout": auto_cashout
                    }
                elif data.get("action") == "cashout" and is_in_flight:
                    user_id = data.get("user_id", 1)
                    if user_id in active_bets:
                        await process_cashout(user_id)
                        active_bets.pop(user_id, None)
    finally:
        clients.remove(ws)

    return ws

app = web.Application()
app.router.add_get("/ws", websocket_handler)

# Современная инициализация цикла
async def main():
    asyncio.create_task(crash_loop())
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 8000)
    await site.start()
    print("🚀 Server running on http://localhost:8000")
    while True:
        await asyncio.sleep(3600)

if __name__ == "__main__":
    asyncio.run(main())
